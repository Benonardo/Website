# Vanilla Minigames - Resourcepack

## Examples

<code> /tellraw @p {"translate":"start"} </code>

<code> /tellraw @p {"translate":"death","with":[{"selector":"@s"}]} </code>

<code> /tellraw @p {"translate":"kill","with":[{"selector":"@s"},{"selector":"@s"}]} </code>

<code> /give @p rose_bush{CustomModelData:1} </code>

## License

<p xmlns:dct="http://purl.org/dc/terms" xmlns:cc="http://creativecommons.org/ns" class="license-text"><a rel="cc:attributionURL" href="http://vanillaminigames.cf"><span rel="dct:title">Vanilla Minigames Resourcepack</span></a> by <a rel="cc:attributionURL" href="https://github.com/DEVTomatoCake"><span rel="cc:attributionName">Vanilla Minigames Team</span></a> CC BY-NC-SA 4.0<a href="https://creativecommons.org/licenses/by-nc-sa/4.0"><img style="height:22px!important;margin-left: 3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/cc.svg" /><img style="height:22px!important;margin-left: 3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/by.svg" /><img  style="height:22px!important;margin-left: 3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/nc.svg" /><img style="height:22px!important;margin-left: 3px;vertical-align:text-bottom;" src="https://mirrors.creativecommons.org/presskit/icons/sa.svg" /></a></p>
